// Generated project
console.log('Project generated');